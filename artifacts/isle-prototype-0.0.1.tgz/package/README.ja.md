# Isle

[English](README.md) · 日本語

[ドキュメント・ライブデモ](https://mizchi.github.io/isle/ja/)

[Playground を開く](https://mizchi.github.io/isle/playground/)。ブラウザー内で Isle・props・CSS を編集してコンパイルし、その場で操作できます。SSR HTML、resume 用モジュール、解析結果も確認できます。カウンター、キー付きリスト、入れ子、SSR 専用の例を用意しています。[ブラウザー API](docs/playground.md)。

Isleは、Qwik型の事前コンパイルとresumeを基盤とするUIライブラリです。CSSのレイアウト契約をcomponentの型システムへ組み込み、必要な領域、実装する配置、状態間の変化を配信前に検査することを目的としています。

SSRするアプリと、外部サイトへ埋め込むWeb Componentsを、操作時に再開するUIとして作れます。`.isle`に状態・表示・イベントの境界とレイアウト契約を書くと、コンパイラが更新先を絞ったDOMコードを生成し、Vite/Rolldownが配信コードを分割します。現行のCSS検査は制約したprofileを対象とし、Layout Instabilityの静的検証は[ADR](docs/adr/README.md)に計画を記録しています。

[目的と設計原則](docs/project-purpose.md) · [別環境への引き継ぎ](docs/handoff.md)

<picture>
  <source media="(max-width: 760px)" srcset="docs/overview/figures/isle-overview.mobile.png">
  <img src="docs/overview/figures/isle-overview.desktop.png" width="1040" alt="Isle の概要。専用構文から SSR の HTML、snapshot、分割 JS/CSS、manifest を生成。先読みと実行を分け、操作された UI を resume する。Form、server action、Web Components widget、制約付き CSS 検査に対応。">
</picture>

初期表示はサーバーの HTML を使い、コンポーネントの初期化をブラウザーで繰り返しません。既定の `auto` ではコードを先読みできますが、状態の復元・resource setup・handler は操作まで遅延します。子コンポーネントは独立して再開し、SSR 専用ページには Isle の browser JS を出力しません。

## はじめる

Node.js 24+ と Vite 8 系（8.3.5 以上）を使います。コンパイル済み frontend をパッケージに含め、レイアウト検査には依存パッケージの Z3 Wasm を使います。MoonBit・Z3 の実行ファイル・コンパイラの checkout を用意する必要はありません。

**プレビュー配布:** パッケージは現在 private です。[プレビュー版の npm アーカイブ](artifacts/isle-prototype-0.0.1.tgz)をダウンロードし、自分のアプリへインストールします。レジストリ公開は別の工程として扱います。パッケージ名と import パスは `@isle/prototype` です。

```sh
pnpm add ./isle-prototype-0.0.1.tgz
pnpm add -D vite@^8.3.5
```

レジストリ公開後は、最初のコマンドを `pnpm add @isle/prototype` に置き換えます。自分のアプリに次の3ファイルを作ります。

### `app.isle`

<!-- file: app.isle -->
```text
client component Counter(initial: number) {
  state count = initial;
  derive doubled = count * 2;
  event increment(event: EventSnapshot<MouseEvent>) { count += 1; }
  event reset(event: EventSnapshot<MouseEvent>) { count = initial; }
  <section>
    <h2>Counter</h2>
    <output aria-live="polite">{count} / {doubled}</output>
    <button type="button" on:click={increment}>Increment</button>
    <button type="button" on:click={reset}>Reset</button>
  </section>
}
```

### `index.html`

<!-- file: index.html -->
```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Isle app</title>
  <style>
    body { max-width: 640px; margin: 32px auto; padding: 0 16px; font: 18px/1.6 system-ui; }
    button { display: block; min-height: 44px; margin: 8px 0; padding: 8px 16px; font: inherit; }
  </style>
</head>
<body>
  <h1>My Isle app</h1>
  <!--isle:ssr-->
</body>
</html>
```

### `vite.config.mjs`

<!-- file: vite.config.mjs -->
```js
import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';
import { isle } from '@isle/prototype/vite';

export default defineConfig({
  plugins: [isle({
    entry: fileURLToPath(new URL('./app.isle', import.meta.url)),
    mounts: [{ component: 'Counter', props: { initial: 5 }, label: 'Counter' }],
  })],
  build: { target: 'es2023' },
});
```

`pnpm exec vite` を実行し、表示された URL を開きます。Counter は `5 / 10` から始まり、Increment で `6 / 12`、Reset で初期値に戻ります。`pnpm exec vite build` でビルドし、`dist/` の出力を確認・配信できます。

この例にブラウザー entry の記述は不要です。`<!--isle:ssr-->` が SSR の HTML の挿入位置で、plugin が操作に必要な loader と chunk も生成します。

このビルドは初期 HTML をビルド時に生成します。リクエスト時の server action には server adapter が必要で、この設定だけで一般のリクエスト時ページレンダラーが構成されるわけではありません。`.isle` の制約付き宣言以外のロジックは、通常の JavaScript の setup / host module に書けます。

## 試せる機能

| 試す機能 | 操作と確認 |
| --- | --- |
| [非同期ローカル地図](examples/async-map/) | 型付きresourceの検索結果をForで更新し、旧task・遅いチャンク・unmountへの応答を検査する。 |
| [TodoMVC](examples/todomvc/) | Todo の追加・編集・絞り込み・保存と、Qwik・Preact との production サイズ比較。 |
| [最小の Counter](examples/hello/) | SSR した値を増やし、初期値へ戻す。 |
| [ブラウザー JS のない SSR](examples/ssr-only/) | ビルドに Isle runtime・snapshot・handler chunk が含まれないことを確認する。 |
| [動的な表示だけ更新](examples/partial-updates/) | 一つの値を変更し、静的見出しと無関係な出力の DOM が保持されることを確かめる。 |
| [入れ子と children](examples/composition/) | 親と子を独立に再開し、純粋 component の children を表示する。 |
| [分岐・key 付きリスト・例外](examples/control-flow/) | 分岐を切り替え、key 付き行を並べ替え、空配列で For の fallback と ErrorBoundary を確認する。 |
| [子へ配置する親のイベント](examples/lexical-events/) | universalなカードへ親のボタンを投影し、見出しクリックでは更新しない。 |
| [manifest による読み込み](examples/loading/) | manifest の先読み判断を調べ、入力時には Search だけが活性化することを確認する。 |
| [リソースの寿命と破棄](examples/resources/) | 所有された timer と listener を活性化し、component を削除して一度だけ破棄されることを見る。 |
| [遅延 CSS と準備完了](examples/styles/) | setup module と CSS を読み込み、setup から見える適用済み style を調べる。 |
| [標準の遷移先読み](examples/navigation/) | Speculation Rules の data block と通常リンクを確認する。Isle の browser JS は出力しない。 |
| [標準フォームの検証](examples/form/) | 不正入力・必須同意・送信成功を、ラベル付きのフォームで試す。 |
| [共通 schema とサーバー検証](examples/schema-form/) | taken@example.com の重複エラーを確認し、修正・送信・reset を試す。 |
| [明示的な server action](examples/counter/) | 独立した Counter と、検証・認可を経由する文書名変更を試す。 |
| [CSS 契約の3つの結果](examples/layout-contracts/) | reset を考慮した Grid/subgrid 契約で verified・violated・unknown を確認する。 |
| [レスポンシブ検査付きビルド](examples/responsive-checked/) | 配信する HTML/CSS の幅×高さ領域を検査し、違反・解析不能でビルドを失敗させる。 |
| [動的構造と scrollbar の検査](examples/responsive-dynamic/) | 上限付きリストの全構造と、native scrollbar の占有幅を検査する。 |
| [ポータブルな Web Components](examples/portable-widget/) | 複数 widget をマウントし、共有版・standalone 版・版の不一致の拒否を確認する。 |
| [Workers からの widget 配信](examples/worker-widget/) | widget-dev と widget-host を別 terminal で起動し、別 origin に固定サイズの Shadow DOM widget を埋め込む。 |

[サンプル一覧](examples/README.ja.md)には、操作・確認ポイント・ソース・検査方法があります。各例の `just` はリポジトリのデモ用コマンドです。利用者のアプリでは、上記の公開 import と Vite のコマンドを使います。

## 境界を選ぶ

- `component Label(title: string)` は server/client 共通の純粋な component です。状態・イベントを使う場合は `client`、server に限定する場合は `server` を付けます。
- [`event` と `on:click`](docs/events.md) で型付きの入力と DOM への接続を宣言します。`.preventDefault` は遅延読み込み前に実行され、本文に `inline(ts)` は不要です。
- [テンプレート内 CSS](docs/inline-css.md) は静的な `<style>` をスコープします。チェック付きビルドは宣言した幅・高さ範囲を Z3 で検査し、playground は Z3 Wasm を必要時に読み込みます。[CSS 変数](docs/css-variables.md)も検査対象の部分集合で静的解決します。
- [CSS略記の検査](docs/css-shorthands.md)で、同一ルール内の暗黙リセットを含む干渉を拒否します。意図的な上書きは別ルールに分けます。アプリのランタイムは増えません。
- [`layout SafeGrid`](docs/layout-contract-language.md) で component の入力範囲と fit 保証を宣言します。Vite・CLI・playground が実際の割当を検査し、アプリのランタイムには追加しません。
- CSS検証コアは独立した[`@mizchi/css-verifier`](packages/css-verifier/README.md)として分離しています。汎用box tree・静的HTMLからも検査でき、Isleはそのadapterです（パッケージは未公開）。
- [`noshift/1`](docs/layout-transitions.md) はDOM要素へ`@noshift`を付け、状態間のboxの存在・位置・寸法を検査します。環境はcomponentの`layout`で宣言し、Vite・CLI・playgroundが有限な候補を比較します。selector指定も維持し、CLS値や中間frameは保証に含めません。
- [`layout PositionedGrid`](examples/layout-contracts/positioned.isle) で名前付きの局所座標系、absoluteの包含、overlay同士の非重複を検査します。[子契約](examples/layout-contracts/positioned-components.isle)では公開rootを接続し、privateな内部も再帰的に検査します。未対応のtransformやscrollはUnknownです。
- [`Show`・`For`・`Switch` / `Match`・`ErrorBoundary`](docs/control-components.md) で構造を保って部分更新します。行のルート、または複数要素をまとめる `Fragment` に `key` を指定します。client component の props は不変の初期値です。
- server action には schema・認可・effect を宣言します。実認証・policy・operation は利用側の server host に実装し、静的配信とは別に接続します。
- `resources` で通常の setup module を component の寿命に接続します。import した CSS は setup の前に準備され、削除時には所有リソースを破棄します。
- `loading: 'auto' | 'lazy' | 'preload' | 'eager'` で解決時期を選びます。preload は取得、eager は起動時の評価も許します。ページ遷移の Speculation Rules は別の設定です。
- `widget` は外部サイト用の Web Components loader と descriptor を生成します。width/height で領域を予約し、共有版・standalone 版を選べます。runtime の版は完全一致させます。

ブラウザー出力は ES2023 と標準の DOM / ESM / fetch を使い、MoonBit / Wasm runtime や polyfill を含めません。動的な領域だけに更新コードを生成しますが、あらゆるアプリで実行時間が短くなることを保証するものではありません。

## 公開 API とガイド

| import / コマンド | 用途 |
| --- | --- |
| `@isle/prototype/vite` | SSR・チャンク・先読み・resources・widget・cost budget の Vite plugin |
| `@isle/prototype/compiler` | server / build 環境での `.isle` のコンパイルと解析 |
| `@isle/prototype/server` | `createActionHandler()` を Request / Response server に接続 |
| `@isle/prototype/widget` / `widget/browser` | 埋め込みタグの生成 / browser widget API |
| `@isle/prototype/layout` | 宣言した CSS / Grid 契約の解析 |
| `@isle/prototype/layout/z3` / `layout/z3/node` | Worker / Node で Z3 検査を行い、証明結果か反例を返す |
| `@isle/prototype/layout/contracts` / `layout/contracts/node` | 契約・CSS の事実・証明義務を分離し、宣言した instance を検査 |
| `@isle/prototype/layout/noshift` / `layout/noshift/node` | sourceのnoshift宣言を有限な候補へ接続し、位置・寸法・存在の安定を検査 |
| `@isle/prototype/resources` | resource owner の API と型 |
| `pnpm exec isle` | source・manifest・cost budget・layout 契約の検査 |

詳しい使い方: [入れ子と children](docs/composition.md)・[Form](docs/forms.md)・[制御構文](docs/control-flow.md)・[読み込み](docs/resolution-optimizer.md)・[widget](docs/widgets.md)・[CSS 契約](docs/layout-checking.md)・[ドキュメント一覧](docs/README.md)。

## 現在の対応範囲

制約付きの式・型を持つ prototype であり、任意の TypeScript を実行する言語ではありません。`inline(ts/moonbit/css)`、Content Mapper、一般の async server render、class 単位の CSS DCE は未実装です。対応する制御構文では閉じた record / array を使えます。

`For` 内の universal な子へ、親が書いたボタンを `children: RenderFragment` で投影できます。見出しや余白には click handler が付きません。[実行例](examples/lexical-events/)で確認できます。別の client owner を越えて可変な内容や親イベントを渡す制限は維持します。

CSS 検査は宣言したサイズ・折り返し・overflow の契約を扱い、`verified`・`violated`・`unknown` を返します。任意の browser layout の証明ではありません。寿命・security の有限モデルは独立した参照モデルで、compiler からのモデル生成や compiler / runtime / browser 全体の証明は今後の機能です。デモの server host は固定 principal とメモリー内のデータを使います。

[開発者向けセットアップと検査](docs/contributing.md)・[設計](docs/design.md)・[形式モデル](models/README.md)・[ベンチマーク](benchmarks/README.md)・[記述評価](evals/README.md)
